const $=s=>document.querySelector(s),P=document.body.dataset.page;
const LOGO=`<svg viewBox="0 0 220 92" role="img" aria-label="Shakey's Pizza Parlor"><ellipse cx="110" cy="46" rx="106" ry="42" fill="#111"/><ellipse cx="110" cy="46" rx="98" ry="35" fill="none" stroke="#ffc72c" stroke-width="3"/><text x="110" y="24" text-anchor="middle" font-family="Montserrat" font-weight="700" font-size="9" letter-spacing="2" fill="#f4e6c8">EST. 1954</text><text x="110" y="58" text-anchor="middle" font-family="Lilita One" font-size="38" fill="#e3242b" stroke="#fff" stroke-width="3.5" paint-order="stroke" transform="rotate(-3 110 46)">Shakey's</text><text x="110" y="76" text-anchor="middle" font-family="Montserrat" font-weight="800" font-size="9.5" letter-spacing="2.5" fill="#ffc72c">PIZZA PARLOR</text></svg>`;
const NAV=[["index.html","Home","home"],["basic.html","Basic","basic"],["upgraded-basic.html","Upgraded Basic","upgraded"],["cake.html","Cake","cake"],["location.html","Location","location"]];
const links=NAV.map(n=>`<a href="${n[0]}"${n[2]===P?' aria-current="page"':""}>${n[1]}</a>`).join("");
$("#hd").innerHTML=`<header><button class="ib" id="burger" aria-label="Menu"><svg viewBox="0 0 24 24"><path d="M4 7h16M4 12h16M4 17h10"/></svg></button><nav aria-label="Main">${links}</nav><a class="logo" href="index.html">${LOGO}</a><a class="ib right" href="location.html" aria-label="Location"><svg viewBox="0 0 24 24"><path d="M12 21s7-6.2 7-11.5A7 7 0 0 0 5 9.5C5 14.8 12 21 12 21z"/><circle cx="12" cy="9.5" r="2.5"/></svg></a></header><div class="drawer" id="dr"><nav><div class="dl">${LOGO}</div>${links}</nav></div>`;
$("#burger").onclick=()=>$("#dr").classList.add("open");$("#dr").onclick=e=>{if(e.target.id==="dr"||e.target.tagName==="A")$("#dr").classList.remove("open")};
$("#ft").innerHTML=`<section class="quote"><div><span class="qm" aria-hidden="true">“</span><blockquote>We serve fun at Shakey's… also pizza.</blockquote><p>Shakey's classic motto · Since 1954</p></div></section><footer>© Shakey's Pizza Parlor · Paciano, Calamba</footer>`;
const SRC={cake:["Cake",DATA.cakes],upgraded:["Upgraded Basic",DATA.backdrops]};
const LABEL={all:"All",k:"Kids & Themes",c:"Christening",m:"Milestone",f:"Characters",h:"Holiday"};
const enc=encodeURI,path=(d,f,t)=>enc(`Images/${d}/${t?"thumbs/":""}${f}`);let view=[],cur=0,filter="all";
const io=new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting){e.target.classList.add("in");io.unobserve(e.target)}}),{rootMargin:"0px 0px -30px"});
function show(){const v=view[cur];$("#lbImg").src=v.src;$("#lbImg").alt=v.t;$("#lbCap").textContent=v.t+(view.length>1?` · ${cur+1} / ${view.length}`:"")}
function openLb(l,i){view=l;cur=i;$("#lb").hidden=false;document.body.style.overflow="hidden";show()}
function closeLb(){$("#lb").hidden=true;document.body.style.overflow=""}
function step(n){cur=(cur+n+view.length)%view.length;show()}
$("#lb .x").onclick=closeLb;$("#lb .pv").onclick=()=>step(-1);$("#lb .nx").onclick=()=>step(1);$("#lb").onclick=e=>{if(e.target.id==="lb")closeLb()};
addEventListener("keydown",e=>{if(e.key==="Escape")$("#dr").classList.remove("open");if($("#lb").hidden)return;if(e.key==="Escape")closeLb();if(e.key==="ArrowLeft")step(-1);if(e.key==="ArrowRight")step(1)});
let sx=0;$("#lb").addEventListener("touchstart",e=>sx=e.touches[0].clientX,{passive:true});$("#lb").addEventListener("touchend",e=>{const d=e.changedTouches[0].clientX-sx;if(Math.abs(d)>50)step(d<0?1:-1)});
const card=(d,dir,k)=>`<img src="${path(dir,d[0],1)}" width="${d[3]}" height="${d[4]}" loading="lazy" alt="${d[1]}"><b>${d[1]}</b>`;
function single(id,src,t,alt){const b=$(id);b.innerHTML=`<span class="card" style="display:block"><img src="${enc(src)}" alt="${alt}" style="aspect-ratio:auto"><b>${t}</b></span>`;b.onclick=()=>openLb([{src:enc(src),t}],0)}
if(SRC[P]){const[dir,list]=SRC[P],g=$("#grid"),c=$("#chips");
 const draw=()=>{g.innerHTML="";const vis=list.filter(d=>filter==="all"||d[2]===filter),lb=vis.map(d=>({src:path(dir,d[0]),t:d[1]}));
  vis.forEach((d,n)=>{const b=document.createElement("button");b.className="card item";b.innerHTML=card(d,dir);b.onclick=()=>openLb(lb,n);g.appendChild(b);io.observe(b)})};
 c.innerHTML=["all",...new Set(list.map(d=>d[2]))].map(t=>`<button class="chip" data-t="${t}" aria-pressed="${t==="all"}">${LABEL[t]}<em>${t==="all"?list.length:list.filter(d=>d[2]===t).length}</em></button>`).join("");
 c.onclick=e=>{const bt=e.target.closest(".chip");if(!bt)return;const t=bt.dataset.t;filter=t;bt.scrollIntoView({inline:"center",block:"nearest",behavior:"smooth"});c.querySelectorAll(".chip").forEach(x=>x.setAttribute("aria-pressed",x.dataset.t===t));draw()};draw()}
if(P==="basic")single("#gBasic","Images/Basic/basic-backdrop-price-guide.jpg","Backdrop styling price guide","Backdrop styling price guide");
if(P==="location")single("#gMap","Images/Location/shakeys-calamba-checkpoint-map.jpg","Shakey's Pizza Parlor, Checkpoint, Calamba","Map showing Shakey's Pizza Parlor on Mayapa-Canlubang Road, Calamba");
if(P==="home")try{const B=DATA.backdrops,C=DATA.cakes,set=(id,d,dir)=>{$(id).src=path(dir,d[0],1)};
 set("#p1",B[30],"Upgraded Basic");set("#p2",B[3],"Upgraded Basic");set("#p3",B[47>B.length-1?20:20],"Upgraded Basic");
 set("#m1",B[30],"Upgraded Basic");set("#m2",B[1],"Upgraded Basic");set("#m3",C[0],"Cake");$("#m4").src="Images/Location/shakeys-calamba-checkpoint-map.jpg";
  const hero=$("#vhero");hero.style.backgroundImage=`url("${path("Upgraded Basic",B[36][0])}")`;
 const v=$("#loopVid"),pp=$("#pp");v.querySelectorAll("source").forEach(x=>x.addEventListener("error",()=>{if(!v.querySelector("source:not([data-bad])"))return;x.dataset.bad=1;if(![...v.querySelectorAll("source")].some(y=>!y.dataset.bad)){v.remove();pp.remove()}}));v.addEventListener("error",()=>{v.remove();pp.remove()});
 pp.onclick=()=>{if(v.paused){v.play();pp.textContent="❚❚"}else{v.pause();pp.textContent="▶"}};
 const cio=new IntersectionObserver(es=>es.forEach(e=>{if(!e.isIntersecting)return;cio.unobserve(e.target);const t=+e.target.dataset.n;let n=0;e.target.textContent=0;const st=Math.max(1,Math.round(t/40)),iv=setInterval(()=>{n=Math.min(t,n+st);e.target.textContent=n;if(n>=t)clearInterval(iv)},30)}));document.querySelectorAll("[data-n]").forEach(x=>cio.observe(x));
 document.querySelectorAll(".rv").forEach(x=>io.observe(x));
 const est=$("#est"),calc=()=>{let t=0;est.querySelectorAll("input:checked").forEach(i=>t+=+i.value);$("#tot").textContent="₱"+t.toLocaleString("en-PH")};est.addEventListener("change",calc);
 }catch(err){document.querySelectorAll(".rv").forEach(x=>x.classList.add("in"))}
